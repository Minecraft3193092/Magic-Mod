
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.magicmod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.CreativeModeTabEvent;

import net.minecraft.world.item.CreativeModeTabs;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MagicmodModTabs {
	@SubscribeEvent
	public static void buildTabContentsVanilla(CreativeModeTabEvent.BuildContents tabData) {

		if (tabData.getTab() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(MagicmodModBlocks.MAGIC_STONE.get().asItem());
			tabData.accept(MagicmodModBlocks.MAGIC_ORE.get().asItem());
			tabData.accept(MagicmodModBlocks.MAGIC_BLOCK.get().asItem());
			tabData.accept(MagicmodModBlocks.MAGIC_WOOD.get().asItem());
			tabData.accept(MagicmodModBlocks.MAGIC_LOG.get().asItem());
			tabData.accept(MagicmodModBlocks.MAGIC_PLANKS.get().asItem());
			tabData.accept(MagicmodModBlocks.MAGIC_STAIRS.get().asItem());
			tabData.accept(MagicmodModBlocks.MAGIC_SLAB.get().asItem());
			tabData.accept(MagicmodModBlocks.MAGIC_BUTTON.get().asItem());
			tabData.accept(MagicmodModBlocks.MAGIC_GLASS.get().asItem());
		}

		if (tabData.getTab() == CreativeModeTabs.REDSTONE_BLOCKS) {
			tabData.accept(MagicmodModBlocks.MAGIC_FENCE_GATE.get().asItem());
			tabData.accept(MagicmodModBlocks.MAGIC_PRESSURE_PLATE.get().asItem());
		}

		if (tabData.getTab() == CreativeModeTabs.COMBAT) {
			tabData.accept(MagicmodModItems.MAGIC_SWORD.get());
			tabData.accept(MagicmodModItems.MAGIC_ARMOR_HELMET.get());
			tabData.accept(MagicmodModItems.MAGIC_ARMOR_CHESTPLATE.get());
			tabData.accept(MagicmodModItems.MAGIC_ARMOR_LEGGINGS.get());
			tabData.accept(MagicmodModItems.MAGIC_ARMOR_BOOTS.get());
		}

		if (tabData.getTab() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(MagicmodModItems.SE_MAGIC_INGOT.get());
			tabData.accept(MagicmodModItems.MAGIC_INGOT.get());
			tabData.accept(MagicmodModItems.MAGIC_WATER_BUCKET.get());
			tabData.accept(MagicmodModItems.MAGIC_IRON_INGOT.get());
			tabData.accept(MagicmodModItems.MAGIC_FUEL.get());
			tabData.accept(MagicmodModItems.MAGICITE_INGOT.get());
		}

		if (tabData.getTab() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(MagicmodModItems.MAGICTOOL.get());
			tabData.accept(MagicmodModItems.MAGIC_PICKAXE.get());
			tabData.accept(MagicmodModItems.MAGIC_AXE.get());
			tabData.accept(MagicmodModItems.MAGIC_SHOVEL.get());
			tabData.accept(MagicmodModItems.MAGIC_HOE.get());
		}

		if (tabData.getTab() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(MagicmodModBlocks.MAGIC_LEAVES.get().asItem());
			tabData.accept(MagicmodModBlocks.MAGIC_FENCE.get().asItem());
			tabData.accept(MagicmodModBlocks.MAGIC_FLOWER.get().asItem());
		}
	}
}
