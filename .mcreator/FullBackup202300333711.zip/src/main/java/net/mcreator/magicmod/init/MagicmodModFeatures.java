
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.magicmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.levelgen.feature.Feature;

import net.mcreator.magicmod.world.features.plants.MagicFlowerFeature;
import net.mcreator.magicmod.world.features.ores.MagicStoneFeature;
import net.mcreator.magicmod.world.features.ores.MagicOreFeature;
import net.mcreator.magicmod.world.features.MagicWaterFeatureFeature;
import net.mcreator.magicmod.MagicmodMod;

@Mod.EventBusSubscriber
public class MagicmodModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.FEATURES, MagicmodMod.MODID);
	public static final RegistryObject<Feature<?>> MAGIC_STONE = REGISTRY.register("magic_stone", MagicStoneFeature::new);
	public static final RegistryObject<Feature<?>> MAGIC_ORE = REGISTRY.register("magic_ore", MagicOreFeature::new);
	public static final RegistryObject<Feature<?>> MAGIC_FLOWER = REGISTRY.register("magic_flower", MagicFlowerFeature::new);
	public static final RegistryObject<Feature<?>> MAGIC_WATER_FEATURE = REGISTRY.register("magic_water_feature", MagicWaterFeatureFeature::new);
}
