
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.magicmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.magicmod.item.SeMagicIngotItem;
import net.mcreator.magicmod.item.MagictoolItem;
import net.mcreator.magicmod.item.MagiciteIngotItem;
import net.mcreator.magicmod.item.MagicWaterItem;
import net.mcreator.magicmod.item.MagicSwordItem;
import net.mcreator.magicmod.item.MagicShovelItem;
import net.mcreator.magicmod.item.MagicPickaxeItem;
import net.mcreator.magicmod.item.MagicIngotItem;
import net.mcreator.magicmod.item.MagicHoeItem;
import net.mcreator.magicmod.item.MagicFuelItem;
import net.mcreator.magicmod.item.MagicAxeItem;
import net.mcreator.magicmod.item.MagicArmorItem;
import net.mcreator.magicmod.item.IronedMagicIngotItem;
import net.mcreator.magicmod.MagicmodMod;

public class MagicmodModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, MagicmodMod.MODID);
	public static final RegistryObject<Item> MAGICTOOL = REGISTRY.register("magictool", () -> new MagictoolItem());
	public static final RegistryObject<Item> MAGIC_STONE = block(MagicmodModBlocks.MAGIC_STONE, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> SE_MAGIC_INGOT = REGISTRY.register("se_magic_ingot", () -> new SeMagicIngotItem());
	public static final RegistryObject<Item> MAGIC_INGOT = REGISTRY.register("magic_ingot", () -> new MagicIngotItem());
	public static final RegistryObject<Item> MAGIC_ORE = block(MagicmodModBlocks.MAGIC_ORE, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> MAGIC_BLOCK = block(MagicmodModBlocks.MAGIC_BLOCK, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> MAGIC_PICKAXE = REGISTRY.register("magic_pickaxe", () -> new MagicPickaxeItem());
	public static final RegistryObject<Item> MAGIC_AXE = REGISTRY.register("magic_axe", () -> new MagicAxeItem());
	public static final RegistryObject<Item> MAGIC_SWORD = REGISTRY.register("magic_sword", () -> new MagicSwordItem());
	public static final RegistryObject<Item> MAGIC_SHOVEL = REGISTRY.register("magic_shovel", () -> new MagicShovelItem());
	public static final RegistryObject<Item> MAGIC_HOE = REGISTRY.register("magic_hoe", () -> new MagicHoeItem());
	public static final RegistryObject<Item> MAGIC_ARMOR_HELMET = REGISTRY.register("magic_armor_helmet", () -> new MagicArmorItem.Helmet());
	public static final RegistryObject<Item> MAGIC_ARMOR_CHESTPLATE = REGISTRY.register("magic_armor_chestplate",
			() -> new MagicArmorItem.Chestplate());
	public static final RegistryObject<Item> MAGIC_ARMOR_LEGGINGS = REGISTRY.register("magic_armor_leggings", () -> new MagicArmorItem.Leggings());
	public static final RegistryObject<Item> MAGIC_ARMOR_BOOTS = REGISTRY.register("magic_armor_boots", () -> new MagicArmorItem.Boots());
	public static final RegistryObject<Item> MAGIC_WOOD = block(MagicmodModBlocks.MAGIC_WOOD, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> MAGIC_LOG = block(MagicmodModBlocks.MAGIC_LOG, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> MAGIC_PLANKS = block(MagicmodModBlocks.MAGIC_PLANKS, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> MAGIC_LEAVES = block(MagicmodModBlocks.MAGIC_LEAVES, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> MAGIC_STAIRS = block(MagicmodModBlocks.MAGIC_STAIRS, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> MAGIC_SLAB = block(MagicmodModBlocks.MAGIC_SLAB, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> MAGIC_FENCE = block(MagicmodModBlocks.MAGIC_FENCE, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> MAGIC_FENCE_GATE = block(MagicmodModBlocks.MAGIC_FENCE_GATE, CreativeModeTab.TAB_REDSTONE);
	public static final RegistryObject<Item> MAGIC_PRESSURE_PLATE = block(MagicmodModBlocks.MAGIC_PRESSURE_PLATE, CreativeModeTab.TAB_REDSTONE);
	public static final RegistryObject<Item> MAGIC_BUTTON = block(MagicmodModBlocks.MAGIC_BUTTON, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> MAGIC_WATER_BUCKET = REGISTRY.register("magic_water_bucket", () -> new MagicWaterItem());
	public static final RegistryObject<Item> MAGIC_GLASS = block(MagicmodModBlocks.MAGIC_GLASS, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> MAGIC_IRON_INGOT = REGISTRY.register("magic_iron_ingot", () -> new IronedMagicIngotItem());
	public static final RegistryObject<Item> MAGIC_FLOWER = block(MagicmodModBlocks.MAGIC_FLOWER, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> MAGIC_FUEL = REGISTRY.register("magic_fuel", () -> new MagicFuelItem());
	public static final RegistryObject<Item> MAGICITE_INGOT = REGISTRY.register("magicite_ingot", () -> new MagiciteIngotItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
