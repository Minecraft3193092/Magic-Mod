
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.magicmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.world.BiomeLoadingEvent;

import net.minecraft.world.level.levelgen.placement.PlacedFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Holder;

import net.mcreator.magicmod.world.features.plants.MagicFlowerFeature;
import net.mcreator.magicmod.world.features.ores.MagicStoneFeature;
import net.mcreator.magicmod.world.features.ores.MagicOreFeature;
import net.mcreator.magicmod.world.features.lakes.MagicWaterFeature;
import net.mcreator.magicmod.MagicmodMod;

import java.util.function.Supplier;
import java.util.Set;
import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber
public class MagicmodModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.FEATURES, MagicmodMod.MODID);
	private static final List<FeatureRegistration> FEATURE_REGISTRATIONS = new ArrayList<>();
	public static final RegistryObject<Feature<?>> MAGIC_STONE = register("magic_stone", MagicStoneFeature::feature,
			new FeatureRegistration(GenerationStep.Decoration.UNDERGROUND_ORES, MagicStoneFeature.GENERATE_BIOMES, MagicStoneFeature::placedFeature));
	public static final RegistryObject<Feature<?>> MAGIC_ORE = register("magic_ore", MagicOreFeature::feature,
			new FeatureRegistration(GenerationStep.Decoration.UNDERGROUND_ORES, MagicOreFeature.GENERATE_BIOMES, MagicOreFeature::placedFeature));
	public static final RegistryObject<Feature<?>> MAGIC_WATER = register("magic_water", MagicWaterFeature::feature,
			new FeatureRegistration(GenerationStep.Decoration.LAKES, MagicWaterFeature.GENERATE_BIOMES, MagicWaterFeature::placedFeature));
	public static final RegistryObject<Feature<?>> MAGIC_FLOWER = register("magic_flower", MagicFlowerFeature::feature, new FeatureRegistration(
			GenerationStep.Decoration.VEGETAL_DECORATION, MagicFlowerFeature.GENERATE_BIOMES, MagicFlowerFeature::placedFeature));

	private static RegistryObject<Feature<?>> register(String registryname, Supplier<Feature<?>> feature, FeatureRegistration featureRegistration) {
		FEATURE_REGISTRATIONS.add(featureRegistration);
		return REGISTRY.register(registryname, feature);
	}

	@SubscribeEvent
	public static void addFeaturesToBiomes(BiomeLoadingEvent event) {
		for (FeatureRegistration registration : FEATURE_REGISTRATIONS) {
			if (registration.biomes() == null || registration.biomes().contains(event.getName()))
				event.getGeneration().getFeatures(registration.stage()).add(registration.placedFeature().get());
		}
	}

	private static record FeatureRegistration(GenerationStep.Decoration stage, Set<ResourceLocation> biomes,
			Supplier<Holder<PlacedFeature>> placedFeature) {
	}
}
