
package net.mcreator.magicmod.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;
import net.minecraftforge.fluids.FluidAttributes;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.magicmod.init.MagicmodModItems;
import net.mcreator.magicmod.init.MagicmodModFluids;
import net.mcreator.magicmod.init.MagicmodModBlocks;

public abstract class MagicWaterFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(MagicmodModFluids.MAGIC_WATER,
			MagicmodModFluids.FLOWING_MAGIC_WATER,
			FluidAttributes.builder(new ResourceLocation("magicmod:blocks/magic_leaves"), new ResourceLocation("magicmod:blocks/magic_wood_leaves"))

	).explosionResistance(100f)

			.bucket(MagicmodModItems.MAGIC_WATER_BUCKET).block(() -> (LiquidBlock) MagicmodModBlocks.MAGIC_WATER.get());

	private MagicWaterFluid() {
		super(PROPERTIES);
	}

	public static class Source extends MagicWaterFluid {
		public Source() {
			super();
		}

		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends MagicWaterFluid {
		public Flowing() {
			super();
		}

		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
